import { QrCode, ScanLine, ArrowLeft, Clock } from 'lucide-react';
import Link from 'next/link';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';

export default function VerifyPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex flex-1 items-center justify-center bg-grid px-4 py-20">
        <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-border bg-card p-10 text-center shadow-xl">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <QrCode className="h-8 w-8" />
          </div>

          <h1 className="mt-6 text-2xl font-bold tracking-tight text-secondary sm:text-3xl">
            Vérification de document
          </h1>

          <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
            Cet espace permettra de scanner un QR code ou de saisir un
            identifiant pour vérifier l&apos;authenticité d&apos;un document
            officiel.
          </p>

          <div className="mt-6 inline-flex items-center gap-2 rounded-lg bg-accent px-4 py-2 text-sm font-medium text-primary">
            <Clock className="h-4 w-4" />
            En développement
          </div>

          <div className="mt-8 flex items-center justify-center gap-3 text-xs text-muted-foreground">
            <ScanLine className="h-4 w-4" />
            La fonctionnalité de scan sera disponible prochainement.
          </div>

          <Link
            href="/"
            className="mt-8 inline-flex items-center gap-2 text-sm font-medium text-foreground transition-colors hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" />
            Retour à l&apos;accueil
          </Link>
        </div>
      </main>

      <Footer />
    </div>
  );
}
