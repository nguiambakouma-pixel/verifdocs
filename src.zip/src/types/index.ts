/**
 * Types TypeScript partagés pour VerifDocs.
 *
 * Cette section sera complétée au fur et à mesure de l'ajout des
 * fonctionnalités métier (documents, établissements, vérifications, etc.).
 */

export type DocumentStatus = 'valid' | 'invalid' | 'expired' | 'revoked';

export interface VerificationResult {
  id: string;
  status: DocumentStatus;
  documentTitle: string;
  issuerName: string;
  issuedAt: string;
  verifiedAt?: string;
}
